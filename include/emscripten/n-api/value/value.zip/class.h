#pragma once

#include <stdio.h>
#include <cstdlib>
#include <memory>
#include <string>
#include <node_api.h>


namespace emscripten {
	namespace napi {
		namespace _value {
			template<typename T>
			struct Class {

				static napi_value create(napi_env env, T val) {

					napi_value res;
					return res;
				}

				static void get(napi_env env, napi_value val, T& res)
				{
				}
			};
		}
	}
}