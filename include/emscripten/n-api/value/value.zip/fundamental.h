#pragma once

#include <stdio.h>
#include <cstdlib>
#include <memory>
#include <string>
#include <node_api.h>


namespace emscripten {
	namespace napi {
		namespace _value {

			template<typename T>
			struct Fundamental;

			template<>
			struct Fundamental <bool> {
				typedef bool type;
				napi_env env_;
				bool     value_;
				Fundamental(napi_env env)
					: env_(env)
				{}

				bool native_cast(napi_value val)
				{
					napi_get_value_bool(env_, val, &value_);
					return value_;
				}

				napi_value napi_cast(bool val) {
					napi_value res;
					napi_get_boolean(env_, val, &res);
					return res;
				}




				static napi_value create(napi_env env, bool val) {
					napi_value res;
					napi_get_boolean(env, val, &res);
					return res;
				}

				static void get(napi_env env, napi_value val, bool& res)
				{
					napi_get_value_bool(env, val, &res);
				}
			};


			template<>
			struct Fundamental <int> {
				typedef int type;
				static napi_value create(napi_env env, int val) {
					napi_value res;
					if (sizeof(int) == 64) {
						napi_create_int64(env, (int64_t)val, &res);
					}
					else {
						napi_create_int32(env, (int32_t)val, &res);
					}
					return res;
				}

				static void get(napi_env env, napi_value val, int& res)
				{
					if (sizeof(int) == 64) {
						napi_get_value_int64(env, val, (int64_t*)&res);
					}
					else {
						napi_get_value_int32(env, val, (int32_t*)&res);
					}
				}
			};

			template<>
			struct Fundamental <double> {
				typedef double type;
				static napi_value create(napi_env env, double val) {
					napi_value res;
					napi_create_double(env, (double)val, &res);
					return res;
				}

				static void get(napi_env env, napi_value val,double& res)
				{
					napi_get_value_double(env, val, &res);
				}
			};








			////

			template<typename T>
			struct Fundamental<const T> : public Fundamental<T> {
			};

			template<typename T>
			struct Fundamental<T&> : public Fundamental<T> {
			};

			template<typename T>
			struct Fundamental<const T&> : public Fundamental<T> {
			};

			template<typename T>
			struct Fundamental<T&&> {
				typedef typename Fundamental<T>::type type;

				static napi_value create(napi_env env, const T& val) {
					return Fundamental<T>::create(env, val);
				}

				static void get(napi_env env, napi_value val, T& res)
				{
					Fundamental<T>::napi_get_value_double(env, val, &res);
				}

			};


		}
	}
}